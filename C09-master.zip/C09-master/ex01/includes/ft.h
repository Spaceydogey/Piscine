#ifndef FT_H
# define FT_H
# define PI 3.14
#endif
